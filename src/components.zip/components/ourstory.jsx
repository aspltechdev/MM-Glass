// StoryBanner.jsx

import "./ourstory.css";

function OurStory() {
  return (
    <section className="story-banner-section">
      
      <div className="story-banner">
        <img
          src="https://images.unsplash.com/photo-1497366754035-f200968a6e72"
          alt="Our Story"
        />

        <div className="story-overlay">
          <button>OUR STORY</button>
        </div>
      </div>

    </section>
  );
}

export default OurStory;