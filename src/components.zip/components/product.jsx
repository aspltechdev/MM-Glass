// Product.jsx

import { useEffect, useState } from "react";
import "./product.css";

function Product() {

  // =========================
  // DATA
  // =========================

  const sections = [
    {
      heading: "Architectural Glass",

      products: [
        {
          title: "Tempered Glass",
          image:
            "https://images.unsplash.com/photo-1513694203232-719a280e022f",
          desc:
            "Processed safety glass with high durability and strength.",
        },

        {
          title: "Heat Soaked Glass",
          image:
            "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85",
          desc:
            "Improves safety against spontaneous glass breakage.",
        },

        {
          title: "Heat Strengthened Glass",
          image:
            "https://images.unsplash.com/photo-1494526585095-c41746248156",
          desc:
            "Twice as strong as annealed glass with clarity.",
        },

        {
          title: "Laminated Glass",
          image:
            "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab",
          desc:
            "Ideal for UV protection and solar control.",
        },

        {
          title: "Reflective Glass",
          image:
            "https://images.unsplash.com/photo-1448630360428-65456885c650",
          desc:
            "Modern architectural reflective safety glass.",
        },

        {
          title: "Insulated Glass",
          image:
            "https://images.unsplash.com/photo-1460317442991-0ec209397118",
          desc:
            "Provides thermal and acoustic insulation.",
        },

        {
          title: "Decorative Glass",
          image:
            "https://images.unsplash.com/photo-1511818966892-d7d671e672a2",
          desc:
            "Elegant decorative glass for interiors.",
        },

        {
          title: "Frosted Glass",
          image:
            "https://images.unsplash.com/photo-1497366754035-f200968a6e72",
          desc:
            "Adds privacy while maintaining natural light.",
        },
      ],
    },

    {
      heading: "Speciality Glass",

      products: [
        {
          title: "Magic Glass",
          image:
            "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
          desc:
            "Switchable privacy glass technology.",
        },

        {
          title: "Curved Glass",
          image:
            "https://images.unsplash.com/photo-1503376780353-7e6692767b70",
          desc:
            "Curved laminated and tempered glass solutions.",
        },

        {
          title: "Georgian Bar Glass",
          image:
            "https://images.unsplash.com/photo-1502877338535-766e1452684a",
          desc:
            "Classic decorative glazing design.",
        },

        {
          title: "Oleo Glass",
          image:
            "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b",
          desc:
            "Remote controlled modern glass solution.",
        },

        {
          title: "Fire Resistant Glass",
          image:
            "https://images.unsplash.com/photo-1513694203232-719a280e022f",
          desc:
            "Designed for fire safety applications.",
        },

        {
          title: "Bullet Resistant Glass",
          image:
            "https://images.unsplash.com/photo-1494526585095-c41746248156",
          desc:
            "Advanced security and protection glass.",
        },

        {
          title: "Acoustic Glass",
          image:
            "https://images.unsplash.com/photo-1497366754035-f200968a6e72",
          desc:
            "Reduces outside noise significantly.",
        },

        {
          title: "Solar Glass",
          image:
            "https://images.unsplash.com/photo-1460317442991-0ec209397118",
          desc:
            "Energy efficient solar control glass.",
        },
      ],
    },

    {
      heading: "Automotive Glass",

      products: [
        {
          title: "Bus Glass",
          image:
            "https://images.unsplash.com/photo-1516321318423-f06f85e504b3",
          desc:
            "Strong safety glass for buses and transport.",
        },

        {
          title: "Car Windshield",
          image:
            "https://images.unsplash.com/photo-1503376780353-7e6692767b70",
          desc:
            "High visibility laminated windshield glass.",
        },

        {
          title: "Truck Glass",
          image:
            "https://images.unsplash.com/photo-1502877338535-766e1452684a",
          desc:
            "Heavy duty truck glass for durability.",
        },

        {
          title: "Transport Glass",
          image:
            "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b",
          desc:
            "Reliable glass for city transportation.",
        },

        {
          title: "Sunroof Glass",
          image:
            "https://images.unsplash.com/photo-1497366754035-f200968a6e72",
          desc:
            "Premium glass for modern vehicles.",
        },

        {
          title: "Rear Safety Glass",
          image:
            "https://images.unsplash.com/photo-1494526585095-c41746248156",
          desc:
            "Enhanced rear passenger protection.",
        },

        {
          title: "Side Window Glass",
          image:
            "https://images.unsplash.com/photo-1511818966892-d7d671e672a2",
          desc:
            "Durable side protection glass.",
        },

        {
          title: "Mirror Glass",
          image:
            "https://images.unsplash.com/photo-1460317442991-0ec209397118",
          desc:
            "Clear visibility mirror glass solutions.",
        },
      ],
    },
  ];

  // =========================
  // SLIDER
  // =========================

  const itemsPerSlide = 4;

  const [slides, setSlides] = useState([0, 0, 0]);

  useEffect(() => {

    const interval = setInterval(() => {

      setSlides((prev) =>
        prev.map((slide, sectionIndex) => {

          const totalSlides = Math.ceil(
            sections[sectionIndex].products.length /
              itemsPerSlide
          );

          return slide === totalSlides - 1
            ? 0
            : slide + 1;

        })
      );

    }, 3000);

    return () => clearInterval(interval);

  }, []);

  const nextSlide = (sectionIndex) => {

    const totalSlides = Math.ceil(
      sections[sectionIndex].products.length /
        itemsPerSlide
    );

    setSlides((prev) =>
      prev.map((slide, index) =>
        index === sectionIndex
          ? slide === totalSlides - 1
            ? 0
            : slide + 1
          : slide
      )
    );
  };

  const prevSlide = (sectionIndex) => {

    const totalSlides = Math.ceil(
      sections[sectionIndex].products.length /
        itemsPerSlide
    );

    setSlides((prev) =>
      prev.map((slide, index) =>
        index === sectionIndex
          ? slide === 0
            ? totalSlides - 1
            : slide - 1
          : slide
      )
    );
  };

  return (
    <>

      {/* =========================
          BANNER
      ========================= */}

      <section className="story-banner-section">

        <div className="story-banner">

          <img
            src="https://images.unsplash.com/photo-1497366754035-f200968a6e72"
            alt="Products"
          />

          <div className="story-overlay">
            <button>PRODUCTS</button>
          </div>

        </div>

      </section>

      {/* =========================
          ALL SECTIONS
      ========================= */}

      {sections.map((section, sectionIndex) => {

        const totalSlides = Math.ceil(
          section.products.length / itemsPerSlide
        );

        return (

          <section
            className="products-section"
            key={sectionIndex}
          >

            {/* Heading */}

            <div className="products-heading">

              <button>
                <span className="dot"></span>
                {section.heading}
              </button>

            </div>

            {/* Slider */}

            <div className="slider-wrapper">

              <div
                className="products-grid-slider"
                style={{
                  transform: `translateX(-${
                    slides[sectionIndex] * 100
                  }%)`,
                }}
              >

                {Array.from({
                  length: totalSlides,
                }).map((_, slideIndex) => (

                  <div
                    className="products-grid"
                    key={slideIndex}
                  >

                    {section.products
                      .slice(
                        slideIndex * itemsPerSlide,
                        slideIndex * itemsPerSlide +
                          itemsPerSlide
                      )
                      .map((item, index) => (

                        <div
                          className="product-card"
                          key={index}
                        >

                          <img
                            src={item.image}
                            alt={item.title}
                          />

                          <div className="product-overlay">

                            <h3>{item.title}</h3>

                            <p>{item.desc}</p>

                          </div>

                        </div>

                      ))}

                  </div>

                ))}

              </div>

            </div>

            {/* Controls */}

            <div className="slider-controls">

              <button
                className="arrow"
                onClick={() =>
                  prevSlide(sectionIndex)
                }
              >
                ‹
              </button>

              <div className="dots">

                {Array.from({
                  length: totalSlides,
                }).map((_, index) => (

                  <span
                    key={index}
                    className={
                      slides[sectionIndex] === index
                        ? "active"
                        : ""
                    }
                    onClick={() => {

                      setSlides((prev) =>
                        prev.map((slide, i) =>
                          i === sectionIndex
                            ? index
                            : slide
                        )
                      );

                    }}
                  ></span>

                ))}

              </div>

              <button
                className="arrow"
                onClick={() =>
                  nextSlide(sectionIndex)
                }
              >
                ›
              </button>

            </div>

            {/* Button */}

            <div className="show-more">

              <button>
                Show More Products
              </button>

            </div>

          </section>

        );
      })}
    </>
  );
}

export default Product;